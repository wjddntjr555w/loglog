var express = require('express');
var path = require('path');
var fs = require('fs');
var multiparty = require('connect-multiparty');
var app = express();
var router = express.Router();

var id = 'jungos';
var password = '1234';

//var bodyParser = require('body-parser');
//app.use(bodyParser.json());
//app.use(bodyParser.urlencoded({extended:false}));


app.get('/',function(req,res){
  fs.readFile('index.html',function(error,data){
    res.writeHead(200,{'Content-Type': 'text/html'});
    res.end(data);
  });
});

app.post('/', function(req,res){
  console.log(req.body);
  // console.log(id+'hhh');
  // console.log(req.body.id);
//  console.log(res.body.id);
  // if(req.body.id == id)
  // {
  //   console.log('ID Ok!');
  //   if(req.body.password == password)
  //   {
  //     console.log('login success');
  //   }
  //   else {
  //     console.log('login fail');
  //   }
  // }
  // else {
  //   console.log('login fail ID');
  // }
});



app.listen(3002, function(){
  console.log('Server On!');
});
